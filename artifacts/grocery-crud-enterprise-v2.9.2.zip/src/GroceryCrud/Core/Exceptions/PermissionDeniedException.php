<?php
namespace GroceryCrud\Core\Exceptions;

class PermissionDeniedException extends \Exception {

}